<?php

namespace AppBundle\Tests\Controller;

use Symfony\Bundle\FrameworkBundle\Test\WebTestCase;

class NoteControllerTest extends WebTestCase
{
    public function testCreateNoteSuccess()
    {
    }

    public function testCreateNoteFailRequiredFields()
    {
    }

    public function testEditNoteSuccess()
    {
    }

    public function testEditNoteFailRequiredFields()
    {
    }

    public function testDeleteNoteSuccess()
    {
    }

    public function testDeleteNoteFailAnotherUser()
    {
    }

    public function testViewNoteSuccess()
    {
    }

    public function testViewNoteFailAnotherUser() {
    }
}

