<?php

namespace AppBundle\Repository;

use Doctrine\ORM\EntityRepository;

/**
 * Class PadRepository
 *
 */
class PadRepository extends EntityRepository
{

}
