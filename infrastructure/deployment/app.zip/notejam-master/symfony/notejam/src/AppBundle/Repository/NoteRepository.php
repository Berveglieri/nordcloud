<?php

namespace AppBundle\Repository;

use Doctrine\ORM\EntityRepository;

/**
 * Class NoteRepository
 *
 */
class NoteRepository extends EntityRepository
{

}
