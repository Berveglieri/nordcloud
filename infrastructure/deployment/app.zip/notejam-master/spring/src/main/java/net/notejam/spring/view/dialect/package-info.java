/**
 * Provides classes for the Notejam Thymeleaf dialect.
 *
 * @author markus@malkusch.de
 * @see <a href="bitcoin:1335STSwu9hST4vcMRppEPgENMHD2r1REK">Donations</a>
 */
package net.notejam.spring.view.dialect;
