# Helper methods defined here can be accessed in any controller or view in the application

module Notejam
  class App
    module UserHelper
    end

    helpers UserHelper
  end
end
