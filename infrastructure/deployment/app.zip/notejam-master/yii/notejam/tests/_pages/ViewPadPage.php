<?php
namespace tests\_pages;

use yii\codeception\BasePage;

class ViewPadPage extends SignedInPage
{
    public $route = 'pad/view';
}
