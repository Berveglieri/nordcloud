<?php
namespace tests\_pages;

use yii\codeception\BasePage;

class ViewNotePage extends SignedInPage
{
    public $route = 'note/view';
}

