Hi, <?= $user->email ?>
=========================================
 
Your new password is <?= $password ?>

