<?php
$this->title = 'New note';
?>

<?= $this->render('form', ['note' => $note]) ?>
