<?php
$this->title = $note->name;
?>

<?= $this->render('form', ['note' => $note]) ?>
