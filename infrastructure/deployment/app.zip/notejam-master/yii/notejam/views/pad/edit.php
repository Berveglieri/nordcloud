<?php
$this->title = $pad->name;
?>

<?= $this->render('form', ['pad' => $pad]) ?>
