<?php
$this->title = 'New pad';
?>

<?= $this->render('form', ['pad' => $pad]) ?>
