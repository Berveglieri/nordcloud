<?php

return [
    'adminEmail' => 'komarserjio@gmail.com',
    'supportEmail' => 'noreply@notejamapp.com',
];
