<?php

return [
    'class' => 'yii\db\Connection',
    'dsn' => 'sqlite:' .  __DIR__ . '/../notejam.db',
    'username' => '',
    'password' => '',
    'charset' => 'utf8',
];
