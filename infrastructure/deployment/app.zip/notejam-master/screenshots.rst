*******************
Notejam screenshots
*******************


**Sign in** page

.. image:: https://github.com/komarserjio/notejam/blob/master/html/screenshots/1.png
    :alt: Sign In
    :width: 835
    :align: center

**All notes** page

.. image:: https://github.com/komarserjio/notejam/blob/master/html/screenshots/2.png
    :alt: All notes
    :width: 835
    :align: center

**New note** page

.. image:: https://github.com/komarserjio/notejam/blob/master/html/screenshots/3.png
    :alt: New note
    :width: 835
    :align: center

**View note** page

.. image:: https://github.com/komarserjio/notejam/blob/master/html/screenshots/4.png
    :alt: View note
    :width: 835
    :align: center

**Account settings** page

.. image:: https://github.com/komarserjio/notejam/blob/master/html/screenshots/5.png
    :alt: Account settings
    :width: 835
    :align: center

**Sign up** page

.. image:: https://github.com/komarserjio/notejam/blob/master/html/screenshots/6.png
    :alt: Sign up
    :width: 835
    :align: center
