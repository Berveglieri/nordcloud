require 'test_helper'

class NoteHelperTest < ActionView::TestCase
end
