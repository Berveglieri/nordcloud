require 'test_helper'

class PadHelperTest < ActionView::TestCase
end
