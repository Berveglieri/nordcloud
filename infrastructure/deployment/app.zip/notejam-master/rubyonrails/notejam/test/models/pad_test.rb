require 'test_helper'

class PadTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
